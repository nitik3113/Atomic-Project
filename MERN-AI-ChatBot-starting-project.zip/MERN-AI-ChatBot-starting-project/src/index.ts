console.log(
  "This is a starter kit for this amazing project. With 💓 By Indian Coders"
);
